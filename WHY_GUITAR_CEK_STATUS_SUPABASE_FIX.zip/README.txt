WHY GUITAR customer status page - Supabase fix.
Upload index.html as the Netlify site. It uses the same Supabase project and reads services.service_no.
